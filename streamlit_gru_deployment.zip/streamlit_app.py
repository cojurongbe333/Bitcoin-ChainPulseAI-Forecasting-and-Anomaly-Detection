
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.models import load_model
from sklearn.preprocessing import MinMaxScaler
import joblib

st.title("📈 Bitcoin Price Forecast with GRU (Tuned)")

# Load data and model
df = pd.read_csv("btcusd_hourly.csv", parse_dates=["ds"])
model = load_model("gru_tuned_model.h5")
scaler = joblib.load("scaler.pkl")

# Prepare sequences
window_size = 50
def create_sequences(data, window):
    X = []
    for i in range(len(data) - window):
        X.append(data[i:i+window])
    return np.array(X)

series = df["y"].values.reshape(-1, 1)
series_scaled = scaler.transform(series)
X_all = create_sequences(series_scaled, window_size)

# Make prediction on last window
X_input = X_all[-168:]
pred_scaled = model.predict(X_input)
pred = scaler.inverse_transform(np.concatenate((pred_scaled, np.zeros((len(pred_scaled), 1))), axis=1))[:,0]

# Plot
st.subheader("Prediction vs Actual")
plt.figure(figsize=(10, 4))
plt.plot(df["ds"].iloc[-168:], df["y"].iloc[-168:], label="Actual")
plt.plot(df["ds"].iloc[-168:], pred, label="Predicted")
plt.xticks(rotation=45)
plt.legend()
st.pyplot(plt)
