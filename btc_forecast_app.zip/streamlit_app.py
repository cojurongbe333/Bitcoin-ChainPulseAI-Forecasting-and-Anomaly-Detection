
import streamlit as st
import pandas as pd
import numpy as np
from keras.models import load_model
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt

st.set_page_config(page_title="Bitcoin Price Forecast (GRU)", layout="wide")

st.title("📈 Bitcoin Price Forecast using Tuned GRU")

@st.cache_data
def load_data():
    df = pd.read_csv("btcusd_1-min_data.csv", parse_dates=["Timestamp"])
    df.set_index("Timestamp", inplace=True)
    df_hourly = df["Close"].resample("1h").mean().dropna().to_frame(name="y")
    df_hourly.reset_index(inplace=True)
    return df_hourly

@st.cache_resource
def load_gru_model():
    return load_model("gru_tuned_model.h5")

@st.cache_data
def preprocess_data(df, window_size=50):
    scaler = MinMaxScaler()
    series_scaled = scaler.fit_transform(df["y"].values.reshape(-1, 1))

    X, y = [], []
    for i in range(window_size, len(series_scaled)):
        X.append(series_scaled[i - window_size:i])
        y.append(series_scaled[i])
    X, y = np.array(X), np.array(y)
    return X, y, scaler

df = load_data()
model = load_gru_model()
X, y, scaler = preprocess_data(df)

split = -168
X_train, X_test = X[:split], X[split:]
y_train, y_test = y[:split], y[split:]

y_pred = model.predict(X_test)
y_pred_inv = scaler.inverse_transform(np.concatenate((y_pred, np.zeros((len(y_pred), 0))), axis=1))[:, 0]
y_test_inv = scaler.inverse_transform(np.concatenate((y_test.reshape(-1, 1), np.zeros((len(y_test), 0))), axis=1))[:, 0]

# Plotting
st.subheader("Forecast vs Actual")
fig, ax = plt.subplots(figsize=(12, 4))
ax.plot(y_test_inv, label="Actual")
ax.plot(y_pred_inv, label="Predicted (GRU - Tuned)")
ax.legend()
st.pyplot(fig)

mae = np.mean(np.abs(y_test_inv - y_pred_inv))
rmse = np.sqrt(np.mean((y_test_inv - y_pred_inv)**2))

st.metric("MAE", f"{mae:.2f}")
st.metric("RMSE", f"{rmse:.2f}")
