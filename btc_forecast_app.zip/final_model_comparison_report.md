
# Final Forecasting Model Report

## 📊 Model Comparison

| Model         | MAE   | RMSE  |
|---------------|-------|--------|
| Prophet       | 56.06 | 63.32 |
| ARIMA         | 40.94 | 52.63 |
| LSTM          | 50.79 | 51.40 |
| GRU (Initial) | 18.60 | 20.10 |
| GRU (Tuned)   | **8.14**  | **9.98**  |
| Transformer (Tuned) | 379.79 | 381.32 |

✅ **Best Performing Model:** GRU (Tuned)

## 🛠 Deployment Setup

To deploy:
```bash
docker build -t btc-gru-app .
docker run -p 8501:8501 btc-gru-app
```

Visit: [http://localhost:8501](http://localhost:8501)
